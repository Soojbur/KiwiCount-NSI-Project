let animalChoisi = ""
let comp = 20
const listeAnimaux = [
    "chats.jpg",
    "chien.jpg",
    "chiens.jpg",
    "ecureuil.jpg",
    "elephant.jpg",
    "girafe.jpg",
    "gorille.jpg",
    "herisson.jpg",
    "iguane.jpg",
    "koala.jpg",
    "lama.jpg",
    "lama-.jpg",
    "lion.jpg",
    "ours.jpg",
    "renard.jpg",
    "rhinoceros.jpg",
    "serpent.jpg",
    "tigre.jpg",
    "tigre-.jpg",
    "tortue.jpg",
    "yack.jpg",
    "zebre.jpg"
];

function tirerUneImageAuSort() {
    // 1. On choisit un index au hasard entre 0 et 21 (la taille du tableau - 1)
    let indexAleatoire = Math.floor(Math.random() * listeAnimaux.length);
    
    // 2. On récupère le nom du fichier à cet index
    let nomFichier = listeAnimaux[indexAleatoire];
    
    // 3. On met à jour l'image dans le HTML
    let slot = document.getElementById('img_animal');
    slot.src = "images/Animaux/" + nomFichier;

    return nomFichier
}

function reset(){
    res.style.backgroundColor = "burlywood";
    res.textContent = ""
    bouton_jouer.disabled = true;
    bouton_verifier.disabled = false;
    guess_input.value = "";
    guess_input.disabled = false
}

function fin_du_jeu(){
    guess_input.value = 0
    bouton_jouer.disabled = false;
    bouton_verifier.disabled = true;
    guess_input.disabled = true

}

function nouvel_essai(){
    animalChoisi = tirerUneImageAuSort().split(".")[0].replace("-", "")

    comp = Math.floor(Math.random() * (20 - 15 + 1)) + 15;
    document.getElementById('complementaire').textContent = comp;

    reset()
}

function verifier_solution(){
    let guess = Number(guess_input.value);
    let reponse = comp - animalChoisi.length;
    if(guess == reponse){
        res.textContent = 'Bravo, tu as gagné !';
        res.style.backgroundColor = "green";
    }
    else{
        res.textContent = "Perdu... Tente un nouvel essai ? L'animal était un "+animalChoisi+", la bonne réponse était donc "+comp.toString()+" - "+animalChoisi.length.toString()+" = "+reponse.toString()+" ...";
        res.style.backgroundColor = "red";
    }
    fin_du_jeu()
}





//------------- MAIN ----------------
let guess_input = document.querySelector("#guess_input");
let bouton_jouer = document.querySelector('#nouvel_essai_button');
let bouton_verifier = document.querySelector('#verifier_reponse');
let res = document.querySelector('#res');

bouton_jouer.addEventListener('click', nouvel_essai);
bouton_verifier.addEventListener('click', verifier_solution);
